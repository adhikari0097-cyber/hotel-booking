const CONFIG = {
  GAS_WEB_APP_URL: "/.netlify/functions/proxy",
};

const ROOM_DEFS = [
  { type: "4-pax", label: "Normal Room", count: 4 },
  { type: "6-pax", label: "6 Pax Room", count: 2 },
  { type: "driver", label: "Driver Room", count: 1 },
];

const TOTAL_ROOMS = ROOM_DEFS.reduce((sum, room) => sum + room.count, 0);

const qs = (selector) => document.querySelector(selector);
const qsa = (selector) => Array.from(document.querySelectorAll(selector));

const bookingForm = qs("#booking-form");
const toast = qs("#toast");
const syncStatus = qs("#sync-status");
const bookingCards = qs("#booking-cards");
const bookingEmpty = qs("#booking-empty");
const roomStatusList = qs("#room-status-list");
const statTotal = qs("#stat-total");
const statOccupied = qs("#stat-occupied");
const statAvailable = qs("#stat-available");
const viewDateInput = qs("#viewDate");
const loadBookingsBtn = qs("#loadBookings");

const navButtons = {
  booking: qs("#tab-booking"),
  view: qs("#tab-view"),
};

const screens = {
  booking: qs("#screen-booking"),
  view: qs("#screen-view"),
};

function showToast(message, isError = false) {
  toast.textContent = message;
  toast.style.background = isError ? "#b5473d" : "#0b3d2e";
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

function setScreen(target) {
  Object.values(screens).forEach((screen) => screen.classList.remove("screen-active"));
  Object.values(navButtons).forEach((btn) => btn.classList.remove("nav-active"));

  screens[target].classList.add("screen-active");
  navButtons[target].classList.add("nav-active");
}

function updateOnlineStatus() {
  syncStatus.textContent = navigator.onLine ? "Online" : "Offline";
  syncStatus.style.background = navigator.onLine ? "#e6f0eb" : "#f9e4e1";
}

function toDateInputValue(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDate(dateString) {
  if (!dateString) return null;
  const [year, month, day] = dateString.split("-").map(Number);
  return new Date(year, month - 1, day, 12, 0, 0);
}

function datesOverlap(startA, endA, startB, endB) {
  return startA < endB && endA > startB;
}

function buildRoomList() {
  return ROOM_DEFS.flatMap((room) => {
    const rooms = [];
    for (let i = 1; i <= room.count; i += 1) {
      rooms.push({
        type: room.type,
        number: i,
        label: room.label,
        fullLabel: `${room.label} ${room.count === 1 ? "" : i}`.trim(),
      });
    }
    return rooms;
  });
}

function getRoomDef(type) {
  return ROOM_DEFS.find((room) => room.type === type);
}

function getRoomLabel(type, number) {
  const def = getRoomDef(type);
  if (!def) return "Room";
  if (def.count === 1) return def.label;
  return `${def.label} ${number}`;
}

function getRoomTypeLabel(type) {
  const def = getRoomDef(type);
  return def ? def.label : type;
}

async function apiGet(action, params = {}) {
  if (!CONFIG.GAS_WEB_APP_URL || CONFIG.GAS_WEB_APP_URL.includes("YOUR_GOOGLE")) {
    throw new Error("Set your Google Apps Script URL in app.js first.");
  }
  const baseUrl = CONFIG.GAS_WEB_APP_URL.startsWith("http")
    ? CONFIG.GAS_WEB_APP_URL
    : `${window.location.origin}${CONFIG.GAS_WEB_APP_URL}`;
  const url = new URL(baseUrl);
  url.searchParams.set("action", action);
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });

  const response = await fetch(url.toString(), { method: "GET" });
  if (!response.ok) {
    throw new Error("Unable to load data from server.");
  }
  return response.json();
}

async function apiPost(payload) {
  if (!CONFIG.GAS_WEB_APP_URL || CONFIG.GAS_WEB_APP_URL.includes("YOUR_GOOGLE")) {
    throw new Error("Set your Google Apps Script URL in app.js first.");
  }
  const baseUrl = CONFIG.GAS_WEB_APP_URL.startsWith("http")
    ? CONFIG.GAS_WEB_APP_URL
    : `${window.location.origin}${CONFIG.GAS_WEB_APP_URL}`;
  const body = new URLSearchParams(payload).toString();
  const response = await fetch(baseUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!response.ok) {
    throw new Error("Unable to save booking.");
  }
  return response.json();
}

async function assignRoomNumber(roomType, checkIn, checkOut) {
  const response = await apiGet("range", {
    roomType,
    start: checkIn,
    end: checkOut,
  });

  const bookings = response.bookings || [];
  const startDate = parseDate(checkIn);
  const endDate = parseDate(checkOut);

  const unavailable = new Set();

  bookings.forEach((booking) => {
    if (booking.status === "Cancelled") return;
    const bookingStart = parseDate(booking.checkIn);
    const bookingEnd = parseDate(booking.checkOut);
    if (!bookingStart || !bookingEnd) return;
    if (!datesOverlap(startDate, endDate, bookingStart, bookingEnd)) return;
    if (booking.roomType !== roomType) return;
    if (booking.roomNumber) {
      unavailable.add(Number(booking.roomNumber));
    }
  });

  const def = getRoomDef(roomType);
  if (!def) return null;

  for (let i = 1; i <= def.count; i += 1) {
    if (!unavailable.has(i)) {
      return i;
    }
  }

  return null;
}

function renderRoomStatus(bookingsForDate) {
  const bookedMap = new Map();

  bookingsForDate.forEach((booking) => {
    if (booking.status === "Cancelled") return;
    const key = `${booking.roomType}-${booking.roomNumber}`;
    bookedMap.set(key, booking.guestName);
  });

  roomStatusList.innerHTML = "";
  buildRoomList().forEach((room) => {
    const key = `${room.type}-${room.number}`;
    const guest = bookedMap.get(key);
    const item = document.createElement("div");
    item.className = "room-item";
    item.innerHTML = `
      <div>
        <span>${room.fullLabel}</span>
        ${guest ? `<div class="muted">${guest}</div>` : ""}
      </div>
      <div class="status ${guest ? "status-booked" : "status-available"}">
        ${guest ? "Booked" : "Available"}
      </div>
    `;
    roomStatusList.appendChild(item);
  });
}

function renderBookings(bookings) {
  bookingCards.innerHTML = "";
  if (!bookings.length) {
    bookingEmpty.textContent = "No bookings for this date.";
    bookingEmpty.style.display = "block";
    return;
  }
  bookingEmpty.style.display = "none";

  bookings.forEach((booking) => {
    const card = document.createElement("div");
    card.className = "booking-card";
    card.innerHTML = `
      <h4>${booking.guestName || "Guest"}</h4>
      <div class="booking-meta">
        <div><strong>Phone:</strong> <a href="tel:${booking.phone}">${booking.phone}</a></div>
        <div><strong>Room:</strong> ${getRoomLabel(booking.roomType, booking.roomNumber)} (#${booking.roomNumber})</div>
        <div><strong>Room type:</strong> ${booking.roomTypeLabel || getRoomTypeLabel(booking.roomType)}</div>
        <div><strong>Dates:</strong> ${booking.checkIn} → ${booking.checkOut}</div>
        <div><strong>Guests:</strong> ${booking.guests}</div>
        <div><strong>Notes:</strong> ${booking.notes || "-"}</div>
      </div>
      <span class="booking-tag">${booking.status || "Confirmed"}</span>
    `;
    bookingCards.appendChild(card);
  });
}

function updateStats(bookings) {
  const bookedRooms = new Set();
  bookings.forEach((booking) => {
    if (booking.status === "Cancelled") return;
    if (booking.roomType && booking.roomNumber) {
      bookedRooms.add(`${booking.roomType}-${booking.roomNumber}`);
    }
  });
  statTotal.textContent = bookings.length;
  statOccupied.textContent = bookedRooms.size;
  statAvailable.textContent = TOTAL_ROOMS - bookedRooms.size;
}

async function loadBookingsForDate(date) {
  if (!date) {
    bookingEmpty.textContent = "Select a date to see bookings.";
    bookingEmpty.style.display = "block";
    return;
  }
  try {
    const response = await apiGet("byDate", { date });
    const bookings = response.bookings || [];

    updateStats(bookings);
    renderRoomStatus(bookings);
    renderBookings(bookings);
  } catch (error) {
    showToast(error.message, true);
  }
}

bookingForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const formData = new FormData(bookingForm);
  const payload = Object.fromEntries(formData.entries());

  if (!payload.guestName || !payload.phone) {
    showToast("Guest name and phone are required.", true);
    return;
  }

  if (!payload.checkIn || !payload.checkOut) {
    showToast("Check-in and check-out dates are required.", true);
    return;
  }

  const checkInDate = parseDate(payload.checkIn);
  const checkOutDate = parseDate(payload.checkOut);
  if (!checkInDate || !checkOutDate || checkOutDate <= checkInDate) {
    showToast("Check-out must be after check-in.", true);
    return;
  }

  const submitButton = bookingForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  submitButton.textContent = "Saving...";

  try {
    const roomNumber = await assignRoomNumber(payload.roomType, payload.checkIn, payload.checkOut);
    if (!roomNumber) {
      throw new Error("No available rooms for these dates.");
    }

    const roomDef = getRoomDef(payload.roomType);
    const response = await apiPost({
      ...payload,
      roomNumber,
      roomTypeLabel: roomDef ? roomDef.label : payload.roomType,
      timestamp: new Date().toISOString(),
    });

    if (!response.success) {
      throw new Error(response.message || "Unable to save booking.");
    }

    bookingForm.reset();
    showToast(`Booking saved. Room ${roomNumber} assigned.`);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Save Booking";
  }
});

loadBookingsBtn.addEventListener("click", () => {
  loadBookingsForDate(viewDateInput.value);
});

viewDateInput.addEventListener("change", (event) => {
  loadBookingsForDate(event.target.value);
});

navButtons.booking.addEventListener("click", () => setScreen("booking"));
navButtons.view.addEventListener("click", () => setScreen("view"));

window.addEventListener("online", updateOnlineStatus);
window.addEventListener("offline", updateOnlineStatus);

(function init() {
  updateOnlineStatus();
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  qs("#checkIn").value = toDateInputValue(today);
  qs("#checkOut").value = toDateInputValue(tomorrow);
  viewDateInput.value = toDateInputValue(today);
  renderRoomStatus([]);
  updateStats([]);

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js");
  }
})();
