# Hotel Booking Mobile (PWA)

A mobile-first, single-page hotel booking tool for staff. Uses Google Sheets + Google Apps Script as the only database. No data is stored locally in the browser.

## 1) Connect Google Apps Script

Create a Google Apps Script Web App that reads/writes to a Google Sheet. Your Web App must support:

### POST (create booking)
Payload JSON fields (sent from `app.js`):
- `guestName` (string)
- `phone` (string)
- `checkIn` (YYYY-MM-DD)
- `checkOut` (YYYY-MM-DD)
- `guests` (number as string)
- `roomType` (`4-pax` | `6-pax` | `driver`)
- `roomTypeLabel` (string)
- `roomNumber` (number)
- `notes` (string)
- `status` (`Confirmed` | `Pending` | `Cancelled`)
- `timestamp` (ISO string)

Response JSON:
```
{ "success": true }
```

### GET (range lookup for auto-room assignment)
Request:
```
?action=range&roomType=4-pax&start=YYYY-MM-DD&end=YYYY-MM-DD
```
Response JSON:
```
{ "success": true, "bookings": [ { "roomType":"4-pax", "roomNumber":1, "checkIn":"2026-03-10", "checkOut":"2026-03-12" } ] }
```

### GET (bookings by date)
Request:
```
?action=byDate&date=YYYY-MM-DD
```
Response JSON:
```
{ "success": true, "bookings": [ { "guestName":"Ava", "phone":"+94...", "roomType":"4-pax", "roomNumber":2, "checkIn":"2026-03-10", "checkOut":"2026-03-12", "guests":2, "notes":"", "status":"Confirmed" } ] }
```

Notes:
- The app assumes **check-out day is NOT occupied** (exclusive end date).
- If you want extra safety, also validate double-booking on the Apps Script side.

## 2) Add your Apps Script URL

Open `app.js` and replace:
```
GAS_WEB_APP_URL: "YOUR_GOOGLE_APPS_SCRIPT_URL_HERE"
```
with your deployed Web App URL.

## 3) Run locally

Serve the folder with any static server. Example:
```
python3 -m http.server 8080
```
Then open: `http://localhost:8080`

## 4) Install as a mobile app (PWA)

On Android (Chrome):
1. Open the site URL.
2. Tap the menu (⋮).
3. Tap **Add to Home screen**.
4. Launch the app from the new icon.

## Files
- `index.html` UI layout
- `styles.css` styling
- `app.js` logic + API calls
- `manifest.json` PWA manifest
- `service-worker.js` offline shell (no data stored)
